# Libraries
Place to keep all external/thirdparty libraries here. Ex: wm-isclient and wm-isserver jars here.